package com.placesdata;

import com.example.expandablelistview.R;



public class PhotoAlbums {
	public static Integer[] mThumbIdsB = { R.drawable.b1,
		R.drawable.b2, R.drawable.b3,
		R.drawable.b4, R.drawable.b5,
		R.drawable.b6, R.drawable.b7,
		R.drawable.b8, R.drawable.b9};

	public static Integer[] mThumbIdsF = { R.drawable.f1,
		R.drawable.f2, R.drawable.f3,
		R.drawable.f4, R.drawable.f6,
		R.drawable.f7, R.drawable.f8,
		R.drawable.f9, R.drawable.f10,
		R.drawable.f11, R.drawable.f12};
	public static Integer[] mThumbIdsL = { R.drawable.l1,
		R.drawable.l2, R.drawable.l3,
		R.drawable.l4, R.drawable.l5,
		R.drawable.l6, R.drawable.l7,
		R.drawable.l8};
	public static Integer[] mThumbIdsI = { R.drawable.i2};
	
	public static Integer[] mThumbIdsM = { R.drawable.m1,
		R.drawable.m2, R.drawable.m3,
		R.drawable.m4, R.drawable.m5,
		R.drawable.m6, R.drawable.m7};
}
