package com.javapapers.android;

public interface Config {

	
	
	 static final String APP_SERVER_URL ="http://192.168.1.4:8084/GCM-Server/GCMNotification?shareRegId=1";

	// Google Project Number
	static final String GOOGLE_PROJECT_ID = "878760951940";
	static final String MESSAGE_KEY = "message";

}
