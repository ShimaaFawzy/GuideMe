/** Automatically generated file. DO NOT MODIFY */
package com.example.expandablelistview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}